module.exports = {
    BACKEND: "http://localhost:5000"
}